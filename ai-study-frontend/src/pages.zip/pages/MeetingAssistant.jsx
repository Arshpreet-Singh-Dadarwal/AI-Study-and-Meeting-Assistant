import Layout from "@/components/Layout";
import {
  Mic,
  MicOff,
  Users,
  CheckSquare,
  FileText,
  Clock,
  Play,
  Square,
} from "lucide-react";
import { useState } from "react";

const MeetingAssistant = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);

  const toggleRecording = () => {
    if (!isRecording) {
      setIsRecording(true);

      const interval = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);

      window.recordingInterval = interval;
    } else {
      setIsRecording(false);
      clearInterval(window.recordingInterval);
      setRecordingTime(0);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  return (
    <Layout>
      <div className="min-h-screen px-6 py-12">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12 animate-fade-in">
            <h1 className="font-display text-4xl md:text-5xl font-bold mb-4">
              <span className="gradient-text">Meeting</span> Assistant
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Record your meetings, get automatic transcriptions, and extract
              action items and key decisions.
            </p>
          </div>

          {/* Recording Interface */}
          <div
            className="glass-card p-8 mb-8 animate-fade-in"
            style={{ animationDelay: "100ms" }}
          >
            <div className="flex flex-col items-center">
              {/* Recording Button */}
              <button
                onClick={toggleRecording}
                className={`relative w-32 h-32 rounded-full flex items-center justify-center transition-all duration-300 ${
                  isRecording
                    ? "bg-destructive animate-pulse-glow"
                    : "bg-gradient-to-br from-primary to-accent hover:scale-105"
                }`}
              >
                {isRecording ? (
                  <Square className="w-12 h-12 text-white" />
                ) : (
                  <Mic className="w-12 h-12 text-white" />
                )}
                {isRecording && (
                  <div className="absolute inset-0 rounded-full border-4 border-destructive animate-ping" />
                )}
              </button>

              {/* Status */}
              <div className="mt-6 text-center">
                {isRecording ? (
                  <>
                    <p className="text-destructive font-semibold text-lg flex items-center gap-2">
                      <span className="w-3 h-3 bg-destructive rounded-full animate-pulse" />
                      Recording...
                    </p>
                    <p className="text-3xl font-display font-bold text-foreground mt-2">
                      {formatTime(recordingTime)}
                    </p>
                  </>
                ) : (
                  <p className="text-muted-foreground">
                    Click to start recording your meeting
                  </p>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-10">
              <QuickAction icon={Play} label="Join Meeting" />
              <QuickAction icon={FileText} label="Upload Recording" />
              <QuickAction icon={Users} label="Add Participants" />
              <QuickAction icon={Clock} label="Schedule" />
            </div>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-2 gap-6">
            <div
              className="glass-card p-6 animate-fade-in"
              style={{ animationDelay: "200ms" }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 rounded-lg bg-accent/10">
                  <FileText className="w-6 h-6 text-accent" />
                </div>
                <h3 className="font-display text-xl font-semibold">
                  Automatic Transcription
                </h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Real-time transcription with speaker identification. Never miss
                a word from your meetings.
              </p>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                  Speaker diarization
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                  Multiple language support
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                  Export to multiple formats
                </li>
              </ul>
            </div>

            <div
              className="glass-card p-6 animate-fade-in"
              style={{ animationDelay: "300ms" }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <CheckSquare className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-display text-xl font-semibold">
                  Action Items
                </h3>
              </div>
              <p className="text-muted-foreground mb-4">
                AI automatically identifies and extracts action items,
                decisions, and follow-ups.
              </p>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                  Task assignment detection
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                  Deadline extraction
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                  Integration with task managers
                </li>
              </ul>
            </div>
          </div>

          {/* Recent Meetings */}
          <div
            className="mt-8 glass-card p-6 animate-fade-in"
            style={{ animationDelay: "400ms" }}
          >
            <h3 className="font-display text-xl font-semibold mb-4">
              Recent Meetings
            </h3>
            <div className="text-center py-8 text-muted-foreground">
              <MicOff className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No meetings recorded yet</p>
              <p className="text-sm mt-1">
                Start recording to see your meetings here
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

const QuickAction = ({ icon: Icon, label }) => (
  <button className="glass-card-glow p-4 flex flex-col items-center gap-2 hover:scale-105 transition-transform duration-300">
    <Icon className="w-6 h-6 text-accent" />
    <span className="text-sm text-muted-foreground">{label}</span>
  </button>
);

export default MeetingAssistant;
