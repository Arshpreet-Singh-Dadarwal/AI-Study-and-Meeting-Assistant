import { useEffect, useState } from "react";
import FileUpload from "../components/FileUpload";
import SummaryBox from "../components/SummaryBox";
import NotesList from "../components/NotesList";
import API from "../api/api";
import Background3D from "../components/Background3D";

export default function Dashboard() {
  const [fileId, setFileId] = useState(null);
  const [summary, setSummary] = useState("");
  const [notes, setNotes] = useState([]);
  const [loadingNotes, setLoadingNotes] = useState(true);

  const fetchNotes = async () => {
    try {
      const res = await API.get("/notes");
      setNotes(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingNotes(false);
    }
  };

  const deleteNote = async (id) => {
    try {
      await API.delete(`/notes/${id}`);
      setNotes((prev) => prev.filter((n) => n._id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  return (
    <div className="relative min-h-screen text-gray-100">
      <Background3D />

      <div className="relative z-10 flex flex-col items-center px-4 pt-20 pb-24">
        {/* HERO GLASS CARD */}
        <div className="w-full max-w-3xl bg-white/10 backdrop-blur-2xl border border-white/20 rounded-3xl p-10 shadow-[0_0_60px_rgba(255,255,255,0.08)]">
          <h1 className="text-center text-4xl md:text-5xl font-extrabold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            AI Study Assistant
          </h1>

          <p className="text-center text-gray-300 mt-3 mb-10">
            Upload your notes and let AI summarize them for you.
          </p>

          <div className="flex flex-col gap-8">
            <FileUpload setFileId={setFileId} />
            <SummaryBox
              fileId={fileId}
              setSummary={setSummary}
              refreshNotes={fetchNotes}
            />

            {/* OUTPUT PANEL */}
            <div className="relative mt-4 bg-black/40 border border-purple-500/30 rounded-2xl p-6 h-72 overflow-y-auto shadow-[0_0_40px_rgba(168,85,247,0.15)]">
              <h3 className="text-purple-300 font-semibold mb-3 text-sm tracking-wider">
                AI OUTPUT
              </h3>

              {summary ? (
                <p className="text-gray-200 leading-loose text-sm whitespace-pre-wrap">
                  {summary}
                </p>
              ) : (
                <div className="h-full flex items-center justify-center text-gray-500 text-sm">
                  No summary generated yet.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* SAVED SUMMARIES */}
        <div className="w-full max-w-5xl mt-20">
          <NotesList
            notes={notes}
            loading={loadingNotes}
            onDelete={deleteNote}
          />
        </div>
      </div>
    </div>
  );
}
